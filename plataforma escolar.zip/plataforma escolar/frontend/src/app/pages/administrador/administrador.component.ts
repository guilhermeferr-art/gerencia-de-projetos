
import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-administrador',
  standalone: true,
  template: `
    <div class="painel">
      <aside class="menu">
        <div class="marca">
          <div class="logo">PE</div>
          <span>Plataforma Escolar</span>
        </div>

        <nav>
          <p class="menu-titulo">MENU PRINCIPAL</p>
          <a class="ativo">▦ Visão geral</a>
          <a>🎮 Jogos educativos</a>
        </nav>

        <button class="sair" (click)="auth.logout()">Sair da plataforma</button>
      </aside>

      <main class="conteudo">
        <header class="cabecalho">
          <div>
            <span>Painel administrativo</span>
            <h1>Olá, {{ auth.getUsuario()?.nome }}!</h1>
          </div>
          <div class="perfil">Professor</div>
        </header>

        <section class="boas-vindas">
          <h2>Bem-vindo à área administrativa!</h2>
          <p>Gerencie os jogos educativos disponíveis na plataforma.</p>
        </section>

        <section class="secao">
          <h2>Gerenciamento da plataforma</h2>

          <div class="cartoes">
            <article class="cartao">
              <div class="icone azul">🎮</div>
              <h3>Jogos educativos</h3>
              <p>Gerencie o catálogo de jogos da plataforma.</p>
              <span>Funcionalidade em desenvolvimento</span>
            </article>

            <article class="cartao">
              <div class="icone roxo">📚</div>
              <h3>Organização</h3>
              <p>Consulte as informações de organização dos jogos.</p>
              <span>Funcionalidade em desenvolvimento</span>
            </article>
          </div>
        </section>
      </main>
    </div>
  `,
  styles: [`
    * { box-sizing: border-box; }

    .painel {
      min-height: 100vh;
      display: flex;
      background: #f5f7fc;
      font-family: Arial, sans-serif;
      color: #1e293b;
    }

    .menu {
      width: 255px;
      background: white;
      padding: 28px 20px;
      border-right: 1px solid #e8edf5;
      display: flex;
      flex-direction: column;
    }

    .marca { display: flex; align-items: center; gap: 10px; font-weight: bold; }

    .logo {
      background: #3867e8;
      color: white;
      padding: 11px;
      border-radius: 10px;
    }

    nav { margin-top: 55px; }
    .menu-titulo { color: #94a3b8; font-size: 11px; letter-spacing: 1px; }

    nav a {
      display: block;
      padding: 14px;
      margin-top: 10px;
      border-radius: 9px;
      color: #64748b;
      text-decoration: none;
    }

    nav a.ativo { background: #edf2ff; color: #3867e8; font-weight: bold; }

    .sair {
      margin-top: auto;
      padding: 13px;
      background: #fff;
      border: 1px solid #e2e8f0;
      border-radius: 9px;
      cursor: pointer;
    }

    .conteudo { flex: 1; padding: 40px; min-width: 0; }

    .cabecalho {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 30px;
    }

    .cabecalho span { color: #64748b; font-size: 13px; }
    .cabecalho h1 { font-size: 27px; margin: 8px 0 0; }

    .perfil {
      background: #edf2ff;
      color: #3867e8;
      padding: 10px 18px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: bold;
    }

    .boas-vindas {
      background: linear-gradient(120deg, #3867e8, #718cf0);
      color: white;
      padding: 30px;
      border-radius: 16px;
    }

    .boas-vindas h2 { margin-top: 0; }
    .boas-vindas p { margin-bottom: 0; opacity: .9; }

    .secao { margin-top: 40px; }
    .cartoes {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 20px;
      margin-top: 20px;
    }

    .cartao {
      background: white;
      border: 1px solid #e8edf5;
      border-radius: 14px;
      padding: 25px;
    }

    .icone {
      width: 50px;
      height: 50px;
      display: grid;
      place-items: center;
      border-radius: 12px;
      font-size: 23px;
    }

    .azul { background: #edf2ff; }
    .roxo { background: #f3eaff; }

    .cartao p { color: #64748b; font-size: 14px; line-height: 1.5; }
    .cartao span { color: #3867e8; font-size: 12px; font-weight: bold; }

    @media (max-width: 750px) {
      .painel { flex-direction: column; }
      .menu { width: 100%; }
      nav { margin-top: 20px; }
      .sair { margin-top: 20px; }
      .conteudo { padding: 25px 18px; }
      .cartoes { grid-template-columns: 1fr; }
    }
  `]
})
export class AdministradorComponent {
  constructor(public auth: AuthService) {}
}
