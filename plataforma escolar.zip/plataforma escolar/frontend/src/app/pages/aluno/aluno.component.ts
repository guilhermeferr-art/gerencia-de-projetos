
import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-aluno',
  standalone: true,
  template: `
    <div class="pagina-aluno">
      <header class="topo">
        <div class="marca">
          <div class="logo">PE</div>
          <span>Plataforma Escolar</span>
        </div>

        <button class="sair" (click)="auth.logout()">Sair</button>
      </header>

      <main class="conteudo">
        <section class="boas-vindas">
          <div>
            <span class="etiqueta">ÁREA DO ALUNO</span>
            <h1>Olá, {{ auth.getUsuario()?.nome }}!</h1>
            <p>Que tal aprender algo novo hoje?</p>
          </div>
          <div class="ilustracao">📚</div>
        </section>

        <section class="informacoes">
          <div class="info-card">
            <span>Minha turma</span>
            <strong>{{ auth.getUsuario()?.turma || 'Não informada' }}</strong>
          </div>

          <div class="info-card">
            <span>Faixa etária</span>
            <strong>{{ auth.getUsuario()?.faixaEtaria || 'Não informada' }}</strong>
          </div>
        </section>

        <section class="jogos">
          <div class="titulo-secao">
            <div>
              <h2>Vamos jogar?</h2>
              <p>Escolha uma atividade para começar a aprender.</p>
            </div>
          </div>

          <div class="jogo-card">
            <div class="jogo-icone">🎮</div>
            <div>
              <h3>Jogos educativos</h3>
              <p>Explore atividades e aprenda brincando!</p>
              <span class="em-breve">Catálogo de jogos em desenvolvimento</span>
            </div>
          </div>
        </section>
      </main>
    </div>
  `,
  styles: [`
    * { box-sizing: border-box; }

    .pagina-aluno {
      min-height: 100vh;
      background: #f5f7fc;
      font-family: Arial, sans-serif;
      color: #1e293b;
    }

    .topo {
      height: 75px;
      padding: 0 7%;
      background: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #e8edf5;
    }

    .marca { display: flex; align-items: center; gap: 12px; font-weight: bold; }

    .logo {
      background: #3867e8;
      color: white;
      padding: 11px;
      border-radius: 10px;
    }

    .sair {
      background: #fff;
      border: 1px solid #dbe2ed;
      padding: 10px 20px;
      border-radius: 8px;
      cursor: pointer;
    }

    .conteudo {
      max-width: 1100px;
      margin: auto;
      padding: 45px 25px;
    }

    .boas-vindas {
      background: linear-gradient(120deg, #3867e8, #718cf0);
      color: white;
      padding: 38px;
      border-radius: 18px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .etiqueta { font-size: 12px; letter-spacing: 2px; opacity: .85; }
    .boas-vindas h1 { font-size: 30px; margin: 15px 0 8px; }
    .boas-vindas p { margin: 0; opacity: .9; }
    .ilustracao { font-size: 65px; }

    .informacoes {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px;
      margin: 28px 0 40px;
    }

    .info-card, .jogo-card {
      background: white;
      padding: 24px;
      border-radius: 14px;
      border: 1px solid #e8edf5;
    }

    .info-card span { display: block; color: #64748b; font-size: 13px; margin-bottom: 10px; }
    .info-card strong { font-size: 19px; }

    .titulo-secao h2 { margin-bottom: 8px; }
    .titulo-secao p { color: #64748b; font-size: 14px; }

    .jogo-card {
      display: flex;
      align-items: center;
      gap: 20px;
      margin-top: 20px;
    }

    .jogo-icone {
      font-size: 35px;
      background: #edf2ff;
      padding: 18px;
      border-radius: 14px;
    }

    .jogo-card h3 { margin: 0 0 8px; }
    .jogo-card p { color: #64748b; font-size: 14px; }
    .em-breve { color: #3867e8; font-size: 12px; font-weight: bold; }

    @media (max-width: 600px) {
      .informacoes { grid-template-columns: 1fr; }
      .boas-vindas { padding: 25px; }
      .boas-vindas h1 { font-size: 23px; }
      .ilustracao { font-size: 42px; }
    }
  `]
})
export class AlunoComponent {
  constructor(public auth: AuthService) {}
}
