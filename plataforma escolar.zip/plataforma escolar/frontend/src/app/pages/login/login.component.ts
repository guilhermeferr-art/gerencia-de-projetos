
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  matricula = '';
  senha = '';

  mensagemErro = '';
  carregando = false;

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  entrar(): void {
    this.mensagemErro = '';

    if (!this.matricula.trim() || !this.senha) {
      this.mensagemErro = 'Preencha todos os campos.';
      return;
    }

    this.carregando = true;

    this.auth.login(
      this.matricula.trim(),
      this.senha
    ).subscribe({
      next: (resposta) => {
        this.carregando = false;

        if (resposta.usuario.perfil === 'aluno') {
          this.router.navigate(['/aluno']);
        } else {
          this.router.navigate(['/admin']);
        }
      },

      error: (erro) => {
        this.carregando = false;

        this.mensagemErro =
          erro.error?.mensagem ||
          'Não foi possível realizar o login.';
      }
    });
  }
}
